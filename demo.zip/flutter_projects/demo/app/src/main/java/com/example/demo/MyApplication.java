package com.example.demo;

import android.app.Application;

import io.flutter.app.FlutterApplication;

public class MyApplication extends FlutterApplication {
    @Override
    public void onCreate() {
        super.onCreate();
        FlutterMediator.init(this);
    }
}
